# (c) JC BAUDIN 2025 04 21
def classFactory(iface):

	from .Rapprocheur import MainPlugin
	return MainPlugin(iface)

