from PyQt5 import QtCore
from PyQt5 import QtGui
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import (QMessageBox, QDialog, QProgressBar, QDialogButtonBox,
                                  QAction, QLabel, QComboBox, QPushButton, QLineEdit, QApplication)
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry,
                       QgsPointXY, QgsPoint, QgsSpatialIndex, QgsFeatureRequest, QgsWkbTypes)
from qgis.utils import iface
import os
import fonctionsF
import doAboutRapprocheur
from math import *
from math import sqrt,cos,sin,acos,pi,pow,atan2



class Ui_Dialog(object):
    def setupUi(self, Dialog):
        self.iface = iface
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0, 0, 360, 320).size()).expandedTo(Dialog.minimumSizeHint()))
        Dialog.setWindowTitle("Rapprocheur")

        # QLabel lancer recherche
        self.label10 = QLabel(Dialog)
        self.label10.setGeometry(QtCore.QRect(15, 15, 360, 18))
        self.label10.setObjectName("label10")
        self.label10.setText("Select a layer B of lines to project (with lines selected):  ")

        ListeCouchesLines = [""]
        NbCouches = self.iface.mapCanvas().layerCount()
        if NbCouches == 0: QMessageBox.information(None, "information:", "No layers! ")
        else:
            for i in range(0, NbCouches):
                couche = self.iface.mapCanvas().layer(i)
                # 0 pour point
                if couche.geometryType() == 1 or couche.geometryType() == 4:
                    if couche.isValid():
                        ListeCouchesLines.append(couche.name())
                    else:
                        QMessageBox.information(None, "information:", "No layers with lines! ")
                        return None
        self.ComboBoxLigneB = QComboBox(Dialog)
        self.ComboBoxLigneB.setMinimumSize(QtCore.QSize(330, 25))
        self.ComboBoxLigneB.setMaximumSize(QtCore.QSize(330, 25))
        self.ComboBoxLigneB.setGeometry(QtCore.QRect(10, 35, 330, 25))
        self.ComboBoxLigneB.setObjectName("ComboBoxLigneB")
        for i in range(len(ListeCouchesLines)):
            self.ComboBoxLigneB.addItem(ListeCouchesLines[i])

        # QLabel de couche ligne
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15, 70, 320, 18))
        self.label.setObjectName("label")
        self.label.setText("Select a target layer A of lines (with lines selected): ")

        ListeCouchesLigne = [""]
        NbCouches = self.iface.mapCanvas().layerCount()
        for i in range(0, NbCouches):
            couche = self.iface.mapCanvas().layer(i)
            # 1 pour ligne
            if couche.geometryType() == 1 or couche.geometryType() == 4:
                if couche.isValid():
                    ListeCouchesLigne.append(couche.name())
                else:
                    QMessageBox.information(None, "information:", "no layer with lines! ")
                    return None

        self.ComboBoxLignesA = QComboBox(Dialog)
        self.ComboBoxLignesA.setMinimumSize(QtCore.QSize(330, 25))
        self.ComboBoxLignesA.setMaximumSize(QtCore.QSize(330, 25))
        self.ComboBoxLignesA.setGeometry(QtCore.QRect(10, 90, 330, 25))
        self.ComboBoxLignesA.setObjectName("ComboBoxLignesA")
        for i in range(len(ListeCouchesLigne)):
            self.ComboBoxLignesA.addItem(ListeCouchesLigne[i])

        # QLabel entrer le facteur k nearest neighbor
        self.labelKNearestNeighbor = QLabel(Dialog)
        self.labelKNearestNeighbor.setGeometry(QtCore.QRect(15, 120, 280, 23))
        self.labelKNearestNeighbor.setObjectName(" KNearestNeighbor")
        self.labelKNearestNeighbor.setText("Enter the k number (see Read-me try 3):")

        self.TextEditKNearestNeighbor = QLineEdit(Dialog)
        self.TextEditKNearestNeighbor.setMinimumSize(QtCore.QSize(40, 20))
        self.TextEditKNearestNeighbor.setMaximumSize(QtCore.QSize(40, 20))
        self.TextEditKNearestNeighbor.setGeometry(QtCore.QRect(265, 120, 40, 20))
        self.TextEditKNearestNeighbor.setObjectName("TextEditKNearestNeighbor")

        # Exemple de QPushButton
        self.DoButton = QPushButton(Dialog)
        self.DoButton.setMinimumSize(QtCore.QSize(200, 20))
        self.DoButton.setMaximumSize(QtCore.QSize(200, 20))
        self.DoButton.setGeometry(QtCore.QRect(60, 150, 200, 20))
        self.DoButton.setObjectName("DoButton")
        self.DoButton.setText(" Plot the projected lines from B to A !")

        # Exemple de QLCDNumber
        self.progressBar = QProgressBar(Dialog)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setMinimumSize(QtCore.QSize(260, 15))
        self.progressBar.setMaximumSize(QtCore.QSize(260, 15))
        self.progressBar.setGeometry(QtCore.QRect(30, 180, 260, 15))
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setTextVisible(True)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setStyleSheet(
            """QProgressBar {border: 2px solid grey; border-radius: 5px; text-align: center;}"""
            """QProgressBar::chunk {background-color: #6C96C6; width: 20px;}"""
        )
        # Pose a minima une valeur de la barre de progression / slide contrôle
        self.progressBar.setValue(0)

        # Exemple de QPushButton
        self.aboutButton = QPushButton(Dialog)
        self.aboutButton.setMinimumSize(QtCore.QSize(70, 20))
        self.aboutButton.setMaximumSize(QtCore.QSize(70, 20))
        self.aboutButton.setGeometry(QtCore.QRect(30, 270, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText(" Read me ")

        self.PushButton = QPushButton(Dialog)
        self.PushButton.setMinimumSize(QtCore.QSize(100, 20))
        self.PushButton.setMaximumSize(QtCore.QSize(100, 20))
        self.PushButton.setGeometry(QtCore.QRect(185, 270, 100, 20))
        self.PushButton.setObjectName("PushButton")
        self.PushButton.setText("Close")

        self.PushButton.clicked.connect(Dialog.reject)
        self.ComboBoxLigneB.activated[str].connect(self.onComboB)
        self.ComboBoxLignesA.activated[str].connect(self.onComboA)
        self.aboutButton.clicked.connect(self.doAbout)
        self.DoButton.clicked.connect(self.Run)

        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def onComboB(self):
        SelectionB = self.ComboBoxLigneB.currentText()
        CoucheB = fonctionsF.getVectorLayerByName(SelectionB)
        counterB = 0
        for featB in CoucheB.selectedFeatures():
            counterB += 1
        if counterB == 0:
            QMessageBox.information(None, "information:", "Select at least one line feature in " + str(CoucheB.name()) + " layer!")

    def onComboA(self):
        SelectionA = self.ComboBoxLignesA.currentText()
        CoucheA = fonctionsF.getVectorLayerByName(SelectionA)
        counterA = 0
        for featA in CoucheA.selectedFeatures():
            counterA += 1
        if counterA == 0:
            QMessageBox.information(None, "information:", "Select at least one line feature in " + str(CoucheA.name()) + " layer!")

    def doAbout(self):
        d = doAboutRapprocheur.Dialog()
        d.exec_()

    def Run(self):
        global CoucheA, CoucheB
        SelectionB = self.ComboBoxLigneB.currentText()
        CoucheB = fonctionsF.getVectorLayerByName(SelectionB)
        if CoucheB is None:
            QMessageBox.information(None, "Information", f"Layer '{SelectionB}' not found.")
            return

        SelectionA = self.ComboBoxLignesA.currentText()
        CoucheA = fonctionsF.getVectorLayerByName(SelectionA)
        if CoucheA is None:
            QMessageBox.information(None, "Information", f"Layer '{SelectionA}' not found.")
            return

        counterB = counterA = counterN = counterProgess = 0

        counterSelec = 0
        counterSelec = int(self.TextEditKNearestNeighbor.text())
        if counterSelec == 0:
            QMessageBox.information(None, "Information", "Enter a value for k, at least 1")
            return

       
        indexBerge = QgsSpatialIndex()
        # Champ de la couche A:
        providerB = CoucheB.dataProvider()
        fieldsB = providerB.fields()
        # creation de la couche de lignes
        # making of projected shortest lines layer
        New_lines_B = QgsVectorLayer("MultiLineString?crs=epsg:2154", "Deplaced_Lines_from_" + str(CoucheB.name()), "memory")
        QgsProject.instance().addMapLayer(New_lines_B)
        prNew_lines_B = New_lines_B.dataProvider()
        for fB in fieldsB:
            znameField = fB.name()
            Type = str(fB.typeName())
            if Type == 'Integer': prNew_lines_B.addAttributes([QgsField(znameField, QVariant.Int)])
            if Type == 'Real': prNew_lines_B.addAttributes([QgsField(znameField, QVariant.Double)])
            if Type == 'String': prNew_lines_B.addAttributes([QgsField(znameField, QVariant.String)])
            else: prNew_lines_B.addAttributes([QgsField(znameField, QVariant.String)])
        listFields_B = [
            QgsField("XDep", QVariant.Double),
            QgsField("YDep", QVariant.Double),
            QgsField("Xproj", QVariant.Double),
            QgsField("Yproj", QVariant.Double)
        ]
        prNew_lines_B.addAttributes(listFields_B)

        # creation couche de points projetes
        # making of projected points layer

        PtsProj = QgsVectorLayer("Point?crs=epsg:2154",'Centoides_zonaux_de_'+ str(CoucheB.name()) + '_projections', "memory")
        QgsProject.instance().addMapLayer(PtsProj)
        prPtsProj = PtsProj.dataProvider()
        providerB = CoucheB.dataProvider()
        fieldsB = providerB.fields()
        for f in fieldsB:
            znameField = f.name()
            Type = str(f.typeName())
            if Type == 'Integer': prPtsProj.addAttributes([QgsField(znameField, QVariant.Int)])
            if Type == 'Real': prPtsProj.addAttributes([QgsField(znameField, QVariant.Double)])
            if Type == 'String': prPtsProj.addAttributes([QgsField(znameField, QVariant.String)])
            else: prPtsProj.addAttributes([QgsField(znameField, QVariant.String)])
        prPtsProj.addAttributes([
            QgsField("DistanceP", QVariant.Double),
            QgsField("XDep", QVariant.Double),
            QgsField("YDep", QVariant.Double),
            QgsField("Xproj", QVariant.Double),
            QgsField("Yproj", QVariant.Double)
        ])

        for featA in CoucheA.selectedFeatures():
            indexBerge.insertFeature(featA)
            counterA += 1
        for featB in CoucheB.selectedFeatures():
            counterB += 1
        # zdim est le compteur de la progress bar
        zDim = counterB
        global DicoB
        DicoB = {}
        if counterB != 0:
            if counterA != 0:
                for featB in CoucheB.selectedFeatures():
                    attributs = featB.attributes()
                    counterProgess += 1
                    geomB = featB.geometry()

                    if geomB.isMultipart():
                        # Transformer chaque multi-ligne en liste de lignes simples
                        multi_lines = geomB.asMultiPolyline()
                    else:
                        # Si ce n'est pas une multi-ligne, on la traite comme une ligne simple
                        multi_lines = [geomB.asPolyline()]

                    for line in multi_lines:
                        listeNoeudB = line
                        geomL2 = QgsGeometry.fromPolylineXY(line)
                        # Calculer la longueur de la ligne
                        length = geomL2.length()
                        # Interpoler le point cherché à mi-longueur
                        if length > 0:
                            interpolate_point = geomL2.interpolate(length / 2)  
                            centroideB = interpolate_point.asPoint()
                        else:    
                            bounding_box = geomL2.boundingBox()
                            # Calculer le centroïde à partir de la bounding box
                            xmin = bounding_box.xMinimum()
                            xmax = bounding_box.xMaximum()
                            ymin = bounding_box.yMinimum()
                            ymax = bounding_box.yMaximum()
                            centroideB = QgsPointXY((xmin + xmax) / 2, (ymin + ymax) / 2)
                        Point_id = featB.id()
                        nearestsfids = indexBerge.nearestNeighbor(centroideB, counterSelec)
                        request = QgsFeatureRequest().setFilterFids(nearestsfids)
                        min_dist = Distance = 0.0
                        nearest_point = None
                        minVal = 0.0
                        first = True
                        for featA in CoucheA.getFeatures(request):
                            geomA = featA.geometry()
                            fidL = featA.id()
                            distinit, mindistpt, aftervertexinit, leftoff = geomA.closestSegmentWithContext(centroideB)
                            ProjPoint = QgsPointXY(mindistpt[0], mindistpt[1])
                            Distance = fonctionsF.magnitude(centroideB, ProjPoint)
                            if first:
                                minVal, nearest_point, after_vertex_init, fidLV, geomAV, first = Distance, ProjPoint, aftervertexinit, fidL, geomA, False
                            else:
                                if Distance < minVal: minVal, nearest_point, after_vertex_init, fidLV, geomAV = Distance, ProjPoint, aftervertexinit, fidL, geomA
                        PProjMin = nearest_point
                        min_dist = minVal
                        
                        listeNoeudBonA = []
                        for p in listeNoeudB:
                            pp = fonctionsF.translater_point(PProjMin, centroideB, p)
                            listeNoeudBonA.append(QgsPoint(pp.x(), pp.y()))  # Convert QgsPointXY to QgsPoint
                        DicoB[Point_id] = [fidLV, centroideB, PProjMin, min_dist, listeNoeudB,listeNoeudBonA]
                        #QMessageBox.information(None,"DicoB:",str(DicoB))
                        Geom = QgsGeometry().fromPointXY(centroideB)
                        #Geom = QgsGeometry().fromPointXY(PProjMin)
                        PX = float(format(centroideB.x(), '.2f'))
                        PY = float(format(centroideB.y(), '.2f'))
                        newfeat = QgsFeature()
                        newfeat.setGeometry(Geom)
                        Values = featB.attributes()
                        Values.append(min_dist)
                        Values.append(fonctionsF.twodecimal(PX))
                        Values.append(fonctionsF.twodecimal(PY))
                        Values.append(fonctionsF.twodecimal(PProjMin.x()))
                        Values.append(fonctionsF.twodecimal(PProjMin.y()))
                        newfeat.setAttributes(Values)

                        PtsProj.startEditing()
                        prPtsProj.addFeatures([newfeat])
                        PtsProj.commitChanges()

                        New_lines_B.startEditing()
                        newfeatNew_lines_B = QgsFeature()
                        geomBonA = QgsGeometry.fromPolyline(listeNoeudBonA)
                        newfeatNew_lines_B.setGeometry(geomBonA)
                        ValuesNew_lines_B = [Point_id]
                        ValuesNew_lines_B.append(fonctionsF.twodecimal(PX))
                        ValuesNew_lines_B.append(fonctionsF.twodecimal(PY))
                        ValuesNew_lines_B.append(fonctionsF.twodecimal(PProjMin.x()))
                        ValuesNew_lines_B.append(fonctionsF.twodecimal(PProjMin.y()))
                        newfeatNew_lines_B.setAttributes(ValuesNew_lines_B)
                        prNew_lines_B.addFeatures([newfeatNew_lines_B])
                        New_lines_B.commitChanges()

                    zPercent = int(100 * counterProgess / zDim)
                    self.progressBar.setValue(zPercent)
                self.iface.mapCanvas().refresh()
