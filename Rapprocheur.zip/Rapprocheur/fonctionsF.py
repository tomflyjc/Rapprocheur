# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Fichier des fonctions du plugin cc
                                 A QGIS plugin
 Projette des points sur une ligne/bordure de polygone à la distance la plus courte: "ClosestPoint"
                              -------------------
        begin                : 2013-11-04
        copyright            : (C) 2019 by Jean-Christophe Baudin d'après "Nearest neighbor between a point layer and a line layer
                               in http://gis.stackexchange.com/questions/396/
                               nearest-pojected-point-from-a-point-
                               layer-on-a-line-or-polygon-outer-ring-layer
        email                : jean-christophe.baudin@ymail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes,QgsPointXY, QgsGeometry
from qgis.PyQt.QtCore import QFileInfo, QSettings, QCoreApplication
from qgis.PyQt.QtCore import QTranslator, qVersion
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox,QDialog

import csv, sys
import re
import os
import os.path
import unicodedata

from osgeo import ogr
from math import *
from math import sqrt,cos,sin,acos,pi,pow,atan2


def vect(p1, p2):
    # Vecteur définit par deux points
    v_x = p2.x() - p1.x()
    v_y = p2.y() - p1.y()
    Vec = QgsPointXY(v_x, v_y)
    return Vec

def twodecimal(number):
    NB=int((number * 100) + 0.5) / 100.0 # Adding 0.5 rounds it up
    return  NB
    
def magnitude(p1, p2):
    if p1==p2: return 1
    else:
        vect_x = p2.x() - p1.x()
        vect_y = p2.y() - p1.y()
        return sqrt(vect_x**2 + vect_y**2)
    
def getVectorLayerByName(NomCouche):
    layermap=QgsProject.instance().mapLayers()
    for name, layer in layermap.items():
        if layer.type()==QgsMapLayer.VectorLayer and layer.name()==NomCouche:
            if layer.isValid():
               return layer
            else:
               return None
def translater_point(A, B, C):
    """
    Calcule le vecteur BA et effectue la translation du point C selon ce vecteur.

    :param A: QgsPointXY du point A
    :param B: QgsPointXY du point B
    :param C: QgsPointXY du point C
    :return: QgsPointXY du point D
    """
    # Calcul du vecteur BA
    vecteur_BA_x = A.x() - B.x()
    vecteur_BA_y = A.y() - B.y()

    # Translation du point C selon le vecteur BA
    D_x = C.x() + vecteur_BA_x
    D_y = C.y() + vecteur_BA_y

    # Création du point D
    D = QgsPointXY(D_x, D_y)

    return D